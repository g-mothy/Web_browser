#!/usr/bin/env python

import gtk, webkit

def  go_bt(widget):
	add = addressbar.get_text()
        if add.startswith("https://"):
		web.open(add)
	else:
		add = "https://" + add
		addressbar.set_text(add)
       		web.open(add)
       
def new_title(view,frame,title):
	win.set_title(title)

def on_click_link(view,frame):
	uri=frame.get_uri()
	addressbar.set_text(uri)

def on_backbutton_clicked(widget):
	web.go_back()
	
def on_forwardbutton_clicked(widget):
	web.go_forward()

def on_homebutton_clicked(widget):
	web.open("https://google.com")

def on_refreshbutton_clicked(widget):
	web.reload()

def on_stopbutton_clicked(widget):
	web.stop_loading()

def set_text(url):
	web.load_uri(url)

def open_history(button):
	set_text("browser.html")

def on_load_changed(WebView,event):
	url=WebView.get-uri()
	history_file=open("browser.html","a+")
        history_file.writelines("* <a href=\"" + url + "\">" +url + "</a><br>")
	history_file.close()


def on_enter(frame):
	url = frame.get_text()
	WebView.load_uri(url)
	if(url == "about:history"):
		open_history(WebView)
		return

win = gtk.Window()
win.set_default_size(1200,600)
win.connect('destroy',lambda w: gtk.main_quit())

box1 = gtk.VBox()
win.add(box1)

box2 = gtk.HBox()
box1.pack_start(box2,False)

homebutton = gtk.Button()
img3=gtk.Image()
img3.set_from_file("home.jpg")
homebutton.add(img3)
box2.pack_start(homebutton,False)
homebutton.connect('clicked',on_homebutton_clicked)

backbutton =gtk.Button()
img=gtk.Image()
img.set_from_file("backbb.jpg")
backbutton.add(img)
box2.pack_start(backbutton,False)
backbutton.connect('clicked',on_backbutton_clicked)

forwardbutton = gtk.Button()
img1=gtk.Image()
img1.set_from_file("forward.jpg")
forwardbutton.add(img1)
box2.pack_start(forwardbutton,False)
forwardbutton.connect('clicked',on_forwardbutton_clicked)

addressbar = gtk.Entry()
box2.pack_start(addressbar)

refreshbutton = gtk.Button()
img2=gtk.Image()
img2.set_from_file("refresh.jpg")
refreshbutton.add(img2)
box2.pack_start(refreshbutton,False)
refreshbutton.connect('clicked',on_refreshbutton_clicked)

gobutton = gtk.Button("GO")
box2.pack_start(gobutton,False)
gobutton.connect('enter', go_bt)

historybutton = gtk.Button()
img4=gtk.Image()
img4.set_from_file("history.jpg")
historybutton.add(img4)
box2.pack_start(historybutton,False)
historybutton.connect('clicked',open_history)

scroller = gtk.ScrolledWindow()
box1.pack_start(scroller)

web = webkit.WebView()
web.open("https://google.com")
web.connect("title-changed",new_title)
web.connect("load-committed",on_click_link)

scroller.add(web)

win.show_all()

gtk.main()  

